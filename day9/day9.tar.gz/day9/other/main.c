#include <func.h>

int main()
{
    int i=10;
    printf("%p\n",&i);
    return 0;
}

