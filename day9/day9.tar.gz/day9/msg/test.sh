#!/bin/bash
./msgsnd 1 hello
./msgsnd 2 world
./msgsnd 3 "ni hen niu"

