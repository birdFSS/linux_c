#include <func.h>

int main(int argc, char* argv[])
{
    time_t begin;
    begin = time(NULL);
    printf("%ld", begin);
    return 0;
}

